package com.example.moviecatalogue

const val IMAGE_BASE = "https://image.tmdb.org/t/p/w500/"